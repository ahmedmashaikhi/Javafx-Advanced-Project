package sample;

import com.jfoenix.controls.JFXTimePicker;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TableCell;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class TimePickerTableCell extends TableCell<Alarm, LocalTime> {
    private final JFXTimePicker timePicker;
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm");;
    public TimePickerTableCell()
    {
        timePicker = new JFXTimePicker();
        timePicker.setEditable(true);
        timePicker.setValue(getItem());
        timePicker.getEditor().setStyle("-fx-text-fill: white");
        //timePicker.setOnAction(event -> commitEdit(timePicker.getValue()) );
        timePicker.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue)
            {
                commitEdit(timePicker.getValue());
            }
        });
        timePicker.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if(event.getCode() == KeyCode.ENTER)
            {
                commitEdit(timePicker.getValue());
            } else if(event.getCode() == KeyCode.ESCAPE)
            {
                cancelEdit();
            }
        });
        setGraphic(timePicker);
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }

    @Override
    protected void updateItem(LocalTime item, boolean empty) {
        super.updateItem(item, empty);
        if(!empty)
        {
            setText(item != null ? dateTimeFormatter.format(item): null);
            if(isEditing() && timePicker != null && item !=null) timePicker.setValue(item);
            setContentDisplay(isEditing() ? ContentDisplay.GRAPHIC_ONLY: ContentDisplay.TEXT_ONLY);
        } else
        {
            setText(null);
            setContentDisplay(ContentDisplay.TEXT_ONLY);
        }

    }

    @Override
    public void startEdit() {
        if(!isEditable() || ! getTableView().isEditable() || !getTableColumn().isEditable() || isEmpty()) return;
        super.startEdit();
        timePicker.setValue(getItem());
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

    }

    @Override
    public void cancelEdit() {
        super.cancelEdit();
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }

    @Override
    public void commitEdit(LocalTime newValue) {
        super.commitEdit(newValue);
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }
}