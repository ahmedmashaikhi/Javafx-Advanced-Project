package sample;

import javafx.scene.control.ContentDisplay;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableCell;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DatePickerTableCell extends TableCell<Alarm, LocalDate> {
    private final DatePicker datePicker;
    private final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("YYYY-MM-dd");;
    public DatePickerTableCell()
    {
        datePicker = new DatePicker();
        datePicker.setEditable(true);
        datePicker.setValue(getItem());
        datePicker.setOnAction(event -> commitEdit(datePicker.getValue()) );

        datePicker.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if(event.getCode() == KeyCode.ENTER)
            {
                commitEdit(datePicker.getValue());
            } else if(event.getCode() == KeyCode.ESCAPE)
            {
                cancelEdit();
            }
        });
        setGraphic(datePicker);
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }

    @Override
    protected void updateItem(LocalDate item, boolean empty) {
        super.updateItem(item, empty);
        if(!empty)
        {
            setText(item != null ? dateTimeFormatter.format(item): null);
            if(isEditing() && datePicker != null && item !=null) datePicker.setValue(item);
            setContentDisplay(isEditing() ? ContentDisplay.GRAPHIC_ONLY: ContentDisplay.TEXT_ONLY);
        } else
        {
            setText(null);
            setContentDisplay(ContentDisplay.TEXT_ONLY);
        }

    }

    @Override
    public void startEdit() {
        if(!isEditable() || ! getTableView().isEditable() || !getTableColumn().isEditable() || isEmpty()) return;
        super.startEdit();
        datePicker.setValue(getItem());
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

    }

    @Override
    public void cancelEdit() {
        super.cancelEdit();
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }

    @Override
    public void commitEdit(LocalDate newValue) {
        super.commitEdit(newValue);
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }
}

