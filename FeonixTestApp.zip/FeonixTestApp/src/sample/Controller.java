package sample;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import de.jensd.fx.glyphs.GlyphIcons;
import de.jensd.fx.glyphs.GlyphsDude;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.application.Platform;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.css.PseudoClass;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.ChoiceBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.File;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Controller implements Initializable {
    public static PseudoClass PENDING = PseudoClass.getPseudoClass("pending");
    public static PseudoClass CRITICAL = PseudoClass.getPseudoClass("critical");
    public static PseudoClass MAJOR = PseudoClass.getPseudoClass("major");
    public static PseudoClass MINOR = PseudoClass.getPseudoClass("minor");
    public static PseudoClass FATAL = PseudoClass.getPseudoClass("fatal");
    public static PseudoClass NORMAL = PseudoClass.getPseudoClass("normal");

    private final ObservableList<Alarm> alarms = FXCollections.observableArrayList(alarm -> new Observable[]{alarm.idProperty(),alarm.pendingProperty(),alarm.alarmTypeProperty(),alarm.alarmStatusProperty(), alarm.alarmDateProperty()});
    private final SortedList<Alarm> sortedList = new SortedList<>(alarms, (alarm1, alarm2) -> alarm1.getAlarmDate().compareTo(alarm2.getAlarmDate()));
    private final FilteredList<Alarm> filteredList = new FilteredList<>(sortedList, alarm -> false);
    private final Random random = new Random();
    private final ObservableList<XYChart.Data<String, Number>> typesChartData = FXCollections.observableArrayList();
    private final ObservableList<XYChart.Data<String, Number>> statusChartData = FXCollections.observableArrayList();
    private final XYChart.Series<String, Number> typesSeries = new XYChart.Series<>(typesChartData);
    private final XYChart.Series<String, Number> statusSeries = new XYChart.Series<>(statusChartData);
    @FXML
    NumberAxis yAxis;
    @FXML
    NumberAxis yAxis1;
    @FXML
    private BorderPane root;
    @FXML
    private Button picViewButton;
    @FXML
    private JFXButton loadButton;
    @FXML
    private JFXButton addButton;
    @FXML
    private JFXDatePicker fromDatePicker;
    @FXML
    private JFXDatePicker toDatePicker;
    @FXML
    private CategoryAxis xAxis;
    @FXML
    private BarChart<String, Number> typesChart;
    @FXML
    private CategoryAxis xAxis1;
    @FXML
    private BarChart<String, Number> statusChart;
    @FXML
    private TableView<Alarm> tv;
    @FXML
    private TableColumn<Alarm, Boolean> pendingCol;
    @FXML
    private TableColumn<Alarm, Number> idCol;
    @FXML
    private TableColumn<Alarm, String> siteCol;
    @FXML
    private TableColumn<Alarm, LocalDate> dateCol;
    @FXML
    private TableColumn<Alarm, LocalTime> timeCol;
    @FXML
    private TableColumn<Alarm, String> dtCol;
    @FXML
    private TableColumn<Alarm, Alarm.AlarmType> typeCol;
    @FXML
    private TableColumn<Alarm, Alarm.AlarmStatus> statusCol;
    @FXML
    private TableColumn<Alarm, String> descCol;
    @FXML
    private TableColumn<Alarm, String> actionsCol;
   // private final static FontAwesomeIconView comIcon = new FontAwesomeIconView(FontAwesomeIcon.CHAIN_BROKEN);
    public void handleLoadButtonAction(ActionEvent event) {
        CompletableFuture<Void> future = CompletableFuture.runAsync(this::generateDummyData);
    }

    private void generateDummyData() {
        Platform.runLater(() -> {
            alarms.clear();
            for (int year = 2019; year < LocalDate.now().getYear(); year++) {
                for (int month = 1; month < 12; month++) {
                    for (int day = 1; day < 28; day++) {
                        Alarm alarm = new Alarm();
                        alarm.setPending(random.nextBoolean());
                        alarm.setSiteName("Site-" + alarm.getId());
                        alarm.setAlarmDate(LocalDate.of(year, month, day));
                        alarm.setAlarmTime(LocalTime.of(random.nextInt(LocalDateTime.MAX.getHour()), random.nextInt(LocalDateTime.MAX.getMinute())));
                        alarm.setActions("None");
                        alarm.setAlarmStatus(Alarm.AlarmStatus.values()[random.nextInt(Alarm.AlarmStatus.values().length)]);
                        alarm.setAlarmType(Alarm.AlarmType.values()[random.nextInt(Alarm.AlarmType.values().length)]);
                        alarm.setDescription(alarm.isPending() + alarm.getSiteName() + ", " + alarm.getAlarmStatus() + "," + alarm.getAlarmDate().toString() + " , " + "," + alarm.getAlarmDate().toString() + " , " + alarm.getAlarmType());
                        alarms.add(alarm);
                    }
                }

            }
        });
    }

    @FXML
    public void handleFilterButtonAction(ActionEvent event) {
        LocalDate startDate = fromDatePicker.getValue().minusDays(1);
        LocalDate finishDate = toDatePicker.getValue().plusDays(1);
        filteredList.setPredicate(alarm -> alarm.getAlarmDate().isAfter(startDate) && alarm.getAlarmDate().isBefore(finishDate));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        fromDatePicker.getEditor().setStyle("-fx-font-weight: bold;-f-alignment:Center");
        toDatePicker.getEditor().setStyle("-fx-font-weight: bold;-f-alignment:Center");
        fromDatePicker.setValue(LocalDate.now().minusYears(2));
        toDatePicker.setValue(LocalDate.now());
        configureTypesChart();
        configureStatusChart();
        configureAlarmsTableView();

        CompletableFuture<Void> future = CompletableFuture.runAsync(() -> generateDummyData());

    }

    private void configureAlarmsTableView() {
        pendingCol.setCellValueFactory(new PropertyValueFactory<>("pending"));
        pendingCol.setCellFactory(CheckBoxTableCell.<Alarm>forTableColumn(pendingCol));
        idCol.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        idCol.setCellFactory(column -> new TableCell<>(){
            @Override
            protected void updateItem(Number integer, boolean b) {
                super.updateItem(integer, b);
                if(b)
                {
                    setText(null);
                    setGraphic(null);
                }else
                {
                    setText(Integer.toString(integer.intValue()));
                    Alarm alarm = this.getTableRow().getItem();

                    if (alarm != null) {

                        switch (alarm.getAlarmType())
                        {
                            case COMMUNICATION -> setGraphic(GlyphsDude.createIcon(FontAwesomeIcon.CHAIN_BROKEN, "16px"));
                            case POWER -> setGraphic(GlyphsDude.createIcon(FontAwesomeIcon.POWER_OFF, "16px"));
                            case ENVIRONMENTAL -> setGraphic(GlyphsDude.createIcon(FontAwesomeIcon.EXTERNAL_LINK_SQUARE, "16px"));
                            case EQUIPMENT -> setGraphic(GlyphsDude.createIcon(FontAwesomeIcon.LAPTOP, "16px"));
                            case QUALITY -> setGraphic(GlyphsDude.createIcon(FontAwesomeIcon.RSS_SQUARE, "16px"));
                            case UNKNOWN -> setGraphic(GlyphsDude.createIcon(FontAwesomeIcon.QUESTION, "16px"));
                        }

                    } else
                    {
                        setGraphic(null);
                    }
                }
            }
        });
        siteCol.setCellValueFactory(new PropertyValueFactory<>("siteName"));
        dateCol.setCellValueFactory(cellData -> cellData.getValue().alarmDateProperty());
        dateCol.setStyle("-fx-alignment:Center");
        dateCol.setCellFactory(column -> new DatePickerTableCell());
        timeCol.setCellValueFactory(cellData -> cellData.getValue().alarmTimeProperty());
        timeCol.setStyle("-fx-alignment:Center");
        timeCol.setCellFactory(column -> new TimePickerTableCell());
        statusCol.setCellValueFactory(cellData -> cellData.getValue().alarmStatusProperty());
        statusCol.setCellFactory(ChoiceBoxTableCell.<Alarm, Alarm.AlarmStatus>forTableColumn(FXCollections.observableArrayList(Alarm.AlarmStatus.values())));
        typeCol.setCellValueFactory(cellData -> cellData.getValue().alarmTypeProperty());
        typeCol.setCellFactory(ChoiceBoxTableCell.<Alarm, Alarm.AlarmType>forTableColumn(FXCollections.observableArrayList(Alarm.AlarmType.values())));
        typeCol.setOnEditCommit(e -> {e.getRowValue().setAlarmType(e.getNewValue());e.getTableView().edit(e.getTablePosition().getRow(), idCol);});
        descCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        descCol.setCellFactory(column -> new TextAreaTableCell());
        actionsCol.setCellValueFactory(new PropertyValueFactory<>("actions"));
        actionsCol.setCellFactory(column -> new TextAreaTableCell());
        tv.setRowFactory(param -> {
            TableRow<Alarm> row = new TableRow<>();
            ChangeListener<Boolean> pendingListener = (observable, oldValue, newValue) -> {
                row.pseudoClassStateChanged(PENDING, false);
                if (newValue != null) {
                    row.pseudoClassStateChanged(PENDING, newValue);
                }
            };
            ChangeListener<Alarm.AlarmStatus> statusChangeListener = (observable, oldValue, newValue) -> {
                row.pseudoClassStateChanged(CRITICAL, false);
                row.pseudoClassStateChanged(MAJOR, false);
                row.pseudoClassStateChanged(MINOR, false);
                row.pseudoClassStateChanged(FATAL, false);

                if (newValue != null) {
                    switch (newValue) {
                        case CRITICAL: {
                            row.pseudoClassStateChanged(CRITICAL, true);
                            break;
                        }
                        case MAJOR: {
                            row.pseudoClassStateChanged(MAJOR, true);
                            break;
                        }
                        case MINOR: {
                            row.pseudoClassStateChanged(MINOR, true);
                            break;
                        }
                        case FATAL: {
                            row.pseudoClassStateChanged(FATAL, true);
                            break;
                        }
                    }
                }
            };
            row.itemProperty().addListener((observable, oldValue, newValue) -> {
                if (oldValue != null) {
                    oldValue.pendingProperty().removeListener(pendingListener);
                    oldValue.alarmStatusProperty().removeListener(statusChangeListener);
                }
                if (newValue != null) {
                    newValue.pendingProperty().addListener(pendingListener);
                    newValue.alarmStatusProperty().addListener(statusChangeListener);
                    resetPseuCode(row);
                    row.pseudoClassStateChanged(PENDING, newValue.isPending());
                    switch (newValue.getAlarmStatus()) {
                        case CRITICAL: {
                            row.pseudoClassStateChanged(CRITICAL, true);
                            break;
                        }
                        case MAJOR: {
                            row.pseudoClassStateChanged(MAJOR, true);
                            break;
                        }
                        case MINOR: {
                            row.pseudoClassStateChanged(MINOR, true);
                            break;
                        }
                        case FATAL: {
                            row.pseudoClassStateChanged(FATAL, true);
                            break;
                        }
                        default: {
                            resetPseuCode(row);
                            break;
                        }
                    }
                } else {
                    resetPseuCode(row);
                }
            });
            return row;
        });
        tv.setEditable(true);
        tv.setItems(filteredList);


    }
    private void resetPseuCode(TableRow<Alarm> row) {
        row.pseudoClassStateChanged(PENDING, false);
        row.pseudoClassStateChanged(CRITICAL, false);
        row.pseudoClassStateChanged(MAJOR, false);
        row.pseudoClassStateChanged(MINOR, false);
        row.pseudoClassStateChanged(FATAL, false);
        row.pseudoClassStateChanged(NORMAL, false);
    }
    private void configureTypesChart() {

        XYChart.Data<String, Number> comData = new XYChart.Data<>("Com", 0.0, Color.RED);
        XYChart.Data<String, Number> pwrData = new XYChart.Data<>("Pwr", 0.0, Color.ORANGE);
        XYChart.Data<String, Number> equipData = new XYChart.Data<>("Equip", 0.0, Color.NAVY);
        XYChart.Data<String, Number> envData = new XYChart.Data<>("Env", 0.0, Color.BROWN);
        XYChart.Data<String, Number> qltyData = new XYChart.Data<>("Qlty", 0.0, Color.TEAL);
        XYChart.Data<String, Number> uknData = new XYChart.Data<>("Unkwn", 0.0, Color.GREY);
        setChartDataNodeforTypes(comData);
        setChartDataNodeforTypes(pwrData);
        setChartDataNodeforTypes(envData);
        setChartDataNodeforTypes(equipData);
        setChartDataNodeforTypes(qltyData);
        setChartDataNodeforTypes(uknData);
        yAxis.setAutoRanging(false);
        yAxis.tickUnitProperty().bind(yAxis.upperBoundProperty().subtract(yAxis.lowerBoundProperty()).divide(10));
        yAxis.upperBoundProperty().bind(Bindings.createDoubleBinding(() ->
                        1.2 * Stream.of(comData.getYValue(),pwrData.getYValue(),envData.getYValue(),equipData.getYValue(),qltyData.getYValue(),uknData.getYValue()).mapToDouble(value -> value.doubleValue()).max().orElse(10),
                comData.YValueProperty(),pwrData.YValueProperty(),envData.YValueProperty(),equipData.YValueProperty(),qltyData.YValueProperty(),uknData.YValueProperty()));
        xAxis.setTickLabelFont(Font.font(xAxis.getTickLabelFont().getFamily(),FontWeight.BOLD,11));
        yAxis.setTickLabelFont(Font.font(yAxis.getTickLabelFont().getFamily(),FontWeight.BOLD,11));
        typesChart.getData().add(typesSeries);

    }



    private void setChartDataNodeforTypes(XYChart.Data<String, Number> data) {
        if (data.getXValue().equals("Com")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmType() == Alarm.AlarmType.COMMUNICATION).count(), filteredList));
        } else if (data.getXValue().equals("Pwr")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmType() == Alarm.AlarmType.POWER).count(), filteredList));
        } else if (data.getXValue().equals("Equip")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmType() == Alarm.AlarmType.EQUIPMENT).count(), filteredList));
        } else if (data.getXValue().equals("Env")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmType() == Alarm.AlarmType.ENVIRONMENTAL).count(), filteredList));
        } else if (data.getXValue().equals("Qlty")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmType() == Alarm.AlarmType.QUALITY).count(), filteredList));
        } else if (data.getXValue().equals("Unkwn")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmType() == Alarm.AlarmType.UNKNOWN).count(), filteredList));
        }
        final Label label = new Label();
        label.setFont(Font.font("Arial Narrow", FontWeight.BOLD, 11));
        label.setStyle("-fx-text-fill:black");
        label.textProperty().bind(data.YValueProperty().asString());
        StackPane pane = new StackPane();
        pane.setAlignment(Pos.TOP_CENTER);
        StackPane.setAlignment(label, Pos.TOP_CENTER);
        pane.setPadding(new Insets(-label.getFont().getSize() * 1.2, 0, 0, 0));
        Color color = (Color) data.getExtraValue();
        if (color != null)
            pane.setStyle("-fx-background-color:rgb(" + color.getRed() * 255 + "," + color.getGreen() * 255 + "," + color.getBlue() * 255 + ");");
        pane.getChildren().add(label);
        data.setNode(pane);
        typesChartData.add(data);
    }
    private void configureStatusChart() {

        XYChart.Data<String, Number> criticalData = new XYChart.Data<>("Critical", 0.0, Color.RED);
        XYChart.Data<String, Number> majorData = new XYChart.Data<>("Major", 0.0, Color.ORANGE);
        XYChart.Data<String, Number> minorData = new XYChart.Data<>("Minor", 0.0, Color.YELLOW);
        XYChart.Data<String, Number> fatalData = new XYChart.Data<>("Fatal", 0.0, Color.GREY);

        setChartDataNodeforStatus(criticalData);
        setChartDataNodeforStatus(majorData);
        setChartDataNodeforStatus(minorData);
        setChartDataNodeforStatus(fatalData);

        yAxis1.setAutoRanging(false);
        yAxis1.tickUnitProperty().bind(yAxis.upperBoundProperty().subtract(yAxis.lowerBoundProperty()).divide(10));
        yAxis1.upperBoundProperty().bind(Bindings.createDoubleBinding(() ->
                        1.2 * Stream.of(criticalData.getYValue(),majorData.getYValue(),minorData.getYValue(),fatalData.getYValue()).mapToDouble(value -> value.doubleValue()).max().orElse(10),
                criticalData.YValueProperty(),majorData.YValueProperty(),minorData.YValueProperty(),fatalData.YValueProperty()));
        xAxis1.setTickLabelFont(Font.font(xAxis1.getTickLabelFont().getFamily(),FontWeight.BOLD,11));
        yAxis1.setTickLabelFont(Font.font(yAxis1.getTickLabelFont().getFamily(),FontWeight.BOLD,11));
        statusChart.getData().add(statusSeries);

    }
    private void setChartDataNodeforStatus(XYChart.Data<String, Number> data) {
        if (data.getXValue().equals("Critical")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmStatus() == Alarm.AlarmStatus.CRITICAL).count(), filteredList));
        } else if (data.getXValue().equals("Major")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmStatus() == Alarm.AlarmStatus.MAJOR).count(), filteredList));
        } else if (data.getXValue().equals("Minor")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmStatus() == Alarm.AlarmStatus.MINOR).count(), filteredList));
        } else if (data.getXValue().equals("Fatal")) {
            data.YValueProperty().bind(Bindings.createLongBinding(() -> filteredList.stream().filter(value -> value.isPending() && value.getAlarmStatus() == Alarm.AlarmStatus.FATAL).count(), filteredList));
        }
        final Label label = new Label();
        label.setFont(Font.font("Arial Narrow", FontWeight.BOLD, 11));
        label.setStyle("-fx-text-fill:black");
        label.textProperty().bind(data.YValueProperty().asString());
        StackPane pane = new StackPane();
        pane.setAlignment(Pos.TOP_CENTER);
        StackPane.setAlignment(label, Pos.TOP_CENTER);
        pane.setPadding(new Insets(-label.getFont().getSize() * 1.2, 0, 0, 0));
        Color color = (Color) data.getExtraValue();
        if (color != null)
            pane.setStyle("-fx-background-color:rgb(" + color.getRed() * 255 + "," + color.getGreen() * 255 + "," + color.getBlue() * 255 + ");");
        pane.getChildren().add(label);
        data.setNode(pane);
        statusChartData.add(data);
    }


    public void handleAddButtonAction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("addSample.fxml"));
            Parent addRoot = loader.load();
            Dialog<Alarm> dialog = new Dialog<>();
            dialog.initOwner(root.getScene().getWindow());
            dialog.initModality(Modality.APPLICATION_MODAL);
            dialog.getDialogPane().setContent(addRoot);
            dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK);
            AddController controller = loader.<AddController>getController();
            Button button = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
            button.disableProperty().bind(controller.getValidity());
            dialog.setResultConverter(buttonType -> {
                return controller.getAlarm();
            });
            dialog.showAndWait().ifPresent(alarm -> {
                alarms.add(alarm);
            });
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void handlePictureViewButtonAction(ActionEvent event) {
        final FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPEG","*.jpg"),
                new FileChooser.ExtensionFilter("PNG","*.png"),
                new FileChooser.ExtensionFilter("BMP","*.bmp")
                );
        final File selectedFile = fileChooser.showOpenDialog(root.getScene().getWindow());
        if(selectedFile != null)
        {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("picViewSample.fxml"));
                Parent parent = loader.load();
                Image image = new Image(selectedFile.toURI().toURL().toExternalForm());
                Stage picDlg = new Stage();
                picDlg.initModality(Modality.APPLICATION_MODAL);
                picDlg.initOwner(root.getScene().getWindow());
                picDlg.setScene(new Scene(parent,400,300));
                loader.<PicViewSample>getController().setImage(image);
                picDlg.showAndWait();
                picDlg.sizeToScene();
            }catch (Exception ex)
            {
                ex.printStackTrace();
            }
        }
    }
}
