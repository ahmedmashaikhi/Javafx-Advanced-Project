package sample;

public class FakeMain {
    public static void main(String[] args) {
        Main.main(args);
    }
}
