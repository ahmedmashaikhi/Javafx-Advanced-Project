package sample;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTimePicker;
import javafx.beans.binding.BooleanBinding;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Dialog;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;


import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.ResourceBundle;

public class AddController implements Initializable {

    @FXML
    private GridPane root;
    @FXML
    private TextField siteText;
    @FXML
    private TextArea descText;
    @FXML
    private TextArea actionsText;
    @FXML
    private JFXDatePicker datePicker;
    @FXML
    private JFXTimePicker timePicker;
    @FXML
    private ComboBox<Alarm.AlarmStatus> statusCombo;
    @FXML
    private  ComboBox<Alarm.AlarmType> typeCombo;

    private Alarm alarm;

    private BooleanBinding validity;
    public Alarm getAlarm() {
        if (alarm == null) alarm = new Alarm();
        alarm.setSiteName(siteText.getText());
        alarm.setAlarmDate(datePicker.getValue());
        alarm.setAlarmTime(timePicker.getValue());
        alarm.setAlarmStatus(statusCombo.getValue());
        alarm.setAlarmType(typeCombo.getValue());
        alarm.setDescription(descText.getText());
        alarm.setActions(actionsText.getText());
        return alarm;
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        datePicker.setValue(LocalDate.now());
        timePicker.setValue(LocalTime.now());
        statusCombo.setItems(FXCollections.observableList(Arrays.asList(Alarm.AlarmStatus.values())));
        typeCombo.setItems(FXCollections.observableList(Arrays.asList(Alarm.AlarmType.values())));
        statusCombo.getSelectionModel().selectFirst();
        typeCombo.getSelectionModel().selectFirst();
    }

    public BooleanBinding getValidity() {
        if (validity == null)
            validity = siteText.textProperty().isEmpty().or(datePicker.valueProperty().isNull()).or(timePicker.valueProperty().isNull()).or(statusCombo.valueProperty().isNull()).or(typeCombo.valueProperty().isNull()).or(descText.textProperty().isEmpty()).or(actionsText.textProperty().isEmpty());

        return validity;
    }
}
