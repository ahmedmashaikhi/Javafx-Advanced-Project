package sample;

import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TableCell;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

public class TextAreaTableCell extends TableCell<Alarm,String> {
    private final TextArea textArea;

    public TextAreaTableCell()
    {
        textArea = new TextArea();
        textArea.setText(getItem());
        textArea.addEventHandler(KeyEvent.KEY_PRESSED, event -> {
            if(event.getCode() == KeyCode.ACCEPT)
            {
                commitEdit(textArea.getText());
            } else if(event.getCode() == KeyCode.ESCAPE )
            {
                cancelEdit();
            }
        });
        textArea.focusedProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue)
            {
                commitEdit(textArea.getText());
            }
        });
        setGraphic(textArea);
        setContentDisplay(ContentDisplay.TEXT_ONLY);

    }

    @Override
    public void startEdit() {
        if(!isEditable() || !getTableRow().isEditable() || !getTableColumn().isEditable() || isEmpty()) return;
        super.startEdit();
        textArea.setText(getItem());
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
        textArea.requestFocus();
    }

    @Override
    protected void updateItem(String item, boolean empty) {
        super.updateItem(item, empty);
        if(empty)
        {
            setText(null);
            setContentDisplay(ContentDisplay.TEXT_ONLY);
        } else
        {
            setText(getItem());
            setContentDisplay(isEditing() ? ContentDisplay.GRAPHIC_ONLY: ContentDisplay.TEXT_ONLY);
        }
    }

    @Override
    public void commitEdit(String newValue) {
        super.commitEdit(newValue);
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }

    @Override
    public void cancelEdit() {
        super.cancelEdit();
        setContentDisplay(ContentDisplay.TEXT_ONLY);
    }
}

