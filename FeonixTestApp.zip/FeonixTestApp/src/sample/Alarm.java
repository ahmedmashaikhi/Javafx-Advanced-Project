package sample;

import javafx.beans.property.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

public class Alarm {
    public  enum AlarmStatus {
        CRITICAL,MAJOR,MINOR,FATAL
    }
    public enum AlarmType{
        COMMUNICATION,POWER,ENVIRONMENTAL,EQUIPMENT,QUALITY,UNKNOWN;
    }
    public  static AtomicInteger atomicInteger =new AtomicInteger(0);
    private final ReadOnlyIntegerWrapper id = new ReadOnlyIntegerWrapper(this,"id",atomicInteger.incrementAndGet());
    private final StringProperty siteName = new SimpleStringProperty(this,"siteName");
    private final ObjectProperty<LocalDate> alarmDate = new SimpleObjectProperty<>(this,"alarmDateTime",LocalDate.now());
    private final ObjectProperty<LocalTime> alarmTime = new SimpleObjectProperty<>(this,"alarmTime",LocalTime.now());
    private final ObjectProperty<AlarmStatus> alarmStatus = new SimpleObjectProperty<>(this,"alarmStatus");
    private final ObjectProperty<AlarmType> alarmType = new SimpleObjectProperty<>(this,"alarmType");
    private final StringProperty description = new SimpleStringProperty(this,"description");
    private final StringProperty actions = new SimpleStringProperty(this,"actions");
    private final BooleanProperty pending = new SimpleBooleanProperty(this,"pending",true);

    public static AtomicInteger getAtomicInteger() {
        return atomicInteger;
    }

    public static void setAtomicInteger(AtomicInteger atomicInteger) {
        Alarm.atomicInteger = atomicInteger;
    }

    public int getId() {
        return id.get();
    }

    public ReadOnlyIntegerProperty idProperty() {
        return id.getReadOnlyProperty();
    }

    public String getSiteName() {
        return siteName.get();
    }

    public StringProperty siteNameProperty() {
        return siteName;
    }

    public void setSiteName(String siteName) {
        this.siteName.set(siteName);
    }

    public LocalDate getAlarmDate() {
        return alarmDate.get();
    }

    public ObjectProperty<LocalDate> alarmDateProperty() {
        return alarmDate;
    }

    public void setAlarmDate(LocalDate alarmDate) {
        this.alarmDate.set(alarmDate);
    }

    public LocalTime getAlarmTime() {
        return alarmTime.get();
    }

    public ObjectProperty<LocalTime> alarmTimeProperty() {
        return alarmTime;
    }

    public void setAlarmTime(LocalTime alarmTime) {
        this.alarmTime.set(alarmTime);
    }

    public AlarmStatus getAlarmStatus() {
        return alarmStatus.get();
    }

    public ObjectProperty<AlarmStatus> alarmStatusProperty() {
        return alarmStatus;
    }

    public void setAlarmStatus(AlarmStatus alarmStatus) {
        this.alarmStatus.set(alarmStatus);
    }

    public AlarmType getAlarmType() {
        return alarmType.get();
    }

    public ObjectProperty<AlarmType> alarmTypeProperty() {
        return alarmType;
    }

    public void setAlarmType(AlarmType alarmType) {

        this.alarmType.set(alarmType);
    }

    public String getDescription() {
        return description.get();
    }

    public StringProperty descriptionProperty() {
        return description;
    }

    public void setDescription(String description) {
        this.description.set(description);
    }

    public String getActions() {
        return actions.get();
    }

    public StringProperty actionsProperty() {
        return actions;
    }

    public void setActions(String actions) {
        this.actions.set(actions);
    }

    public boolean isPending() {
        return pending.get();
    }

    public BooleanProperty pendingProperty() {
        return pending;
    }

    public void setPending(boolean pending) {
        this.pending.set(pending);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Alarm)) return false;
        Alarm alarm = (Alarm) o;
        return Objects.equals(id, alarm.id) &&
                Objects.equals(siteName, alarm.siteName) &&
                Objects.equals(alarmDate, alarm.alarmDate) &&
                Objects.equals(alarmTime, alarm.alarmTime) &&
                Objects.equals(alarmStatus, alarm.alarmStatus) &&
                Objects.equals(alarmType, alarm.alarmType) &&
                Objects.equals(description, alarm.description) &&
                Objects.equals(actions, alarm.actions) &&
                Objects.equals(pending, alarm.pending);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, siteName, alarmDate, alarmTime, alarmStatus, alarmType, description, actions, pending);
    }

    @Override
    public String toString() {
        return "Alarm{" +
                "id=" + id.get() +
                ", siteName=" + siteName.get() +
                ", alarmDate=" + alarmDate.get() +
                ", alarmTime=" + alarmTime.get() +
                ", alarmStatus=" + alarmStatus.get() +
                ", alarmType=" + alarmType.get() +
                ", description=" + description.get() +
                ", actions=" + actions.get() +
                ", pending=" + pending.get() +
                '}';
    }
}
